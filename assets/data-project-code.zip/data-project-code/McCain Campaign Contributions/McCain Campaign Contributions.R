library(tidyverse)
library(waffle)

jm <- data.frame(
  category = c("Large Contributions", "Federal Funds","Other","Small Individual Contributions (< $200)"),
  percent = c(37,23,23,17)
)

jm_waffle <- jm[rep(1:nrow(jm), jm$percent), ]

jm_waffle$x <- rep(1:10, length.out = nrow(jm_waffle))
jm_waffle$y <- ceiling(seq_along(jm_waffle$x) / 10)

jm_waffle$category <- factor(
  jm_waffle$category,
  levels = c(
    "Large Contributions",
    "Federal Funds",
    "Other",
    "Small Individual Contributions (< $200)"
  )
)


ggplot(jm_waffle, aes(x, y, fill = category)) +
  geom_tile(color = "white") +
  coord_equal() +
  scale_y_reverse() +
  labs(
    title = "2008 McCain Campaign Contributions",
    fill = "Contribution Type",
    subtitle = "Each square represents approximately 1% of total contributions (~$3.67 million)",
    caption = "via OpenSecrets"
  ) +
  theme_void() +
  scale_fill_manual(values = c(
    "#641220",
    "#b21e35",
    "#ffb4a2",
    "#c32f27"
  ))

ggsave("McCain Campaign Contributions.png")
