library(tidyverse)
library(waffle)

jm2 <- data.frame(
  category = c("Large Contributions", "Federal Funds","Other","Small Individual Contributions (< $200)"),
  squares = c(19,11,11,9)
)

jm2_waffle <- jm2[rep(1:nrow(jm2), jm2$squares), ]

jm2_waffle$x <- rep(1:10, length.out = nrow(jm2_waffle))
jm2_waffle$y <- ceiling(seq_along(jm2_waffle$x) / 10)

jm2_waffle$category <- factor(
  jm2_waffle$category,
  levels = c(
    "Large Contributions",
    "Federal Funds",
    "Other",
    "Small Individual Contributions (< $200)"
  )
)


ggplot(jm2_waffle, aes(x, y, fill = category)) +
  geom_tile(color = "white") +
  coord_equal() +
  scale_y_reverse() +
  labs(
    title = "2008 McCain Campaign Contributions (In Close Relation to Obama)",
    fill = "Contribution Type",
    subtitle = "Each square represents approximately 2% of total contributions (~$7.33 million)",
    caption = "via OpenSecrets"
  ) +
  theme_void() +
  scale_fill_manual(values = c(
    "#641220",
    "#b21e35",
    "#ffb4a2",
    "#c32f27"
  ))

ggsave("McCain Campaign Relation Contributions.png")
