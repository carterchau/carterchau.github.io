library(tidyverse)
library(janitor)

internet_data <- read_csv("Internet Usage Graph (Figure 2)/internet usage from 2000-2008 - Sheet1.csv") |>
  clean_names() |>
  mutate(month_num = match(month, month.name))

clean_data <- internet_data |>
  mutate(date = as.Date(paste(year, month_num, "01", sep = "-")))

cleaner <- clean_data[-27,]
  

ggplot(cleaner, aes(x = date, y = percentage)) + 
  geom_line(size = 1.2, color = "#eb7bc0") + 
  geom_point(size = 2, color = "#c46bae") + 
  theme_minimal(base_size = 13)+
  geom_text(
    aes(label = ifelse(date %in% as.Date(c("2000-05-01","2005-09-01","2008-07-01", "2000-12-01","2002-01-01","2003-02-01","2005-01-01","2007-12-01")),
                       paste0(percentage,"%"), "")),
    vjust = -1,
    size = 2.8
  ) +
  labs(
    title = "Internet Usage by American Adults",
    x = NULL,
    y = "Population Percent of Adult Users", 
    caption = "via PewResearchCenter"
  ) +
  scale_y_continuous(labels = function(x) paste0(x, "%"))

ggsave("internet usage growth.png")
 