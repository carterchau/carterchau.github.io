library(tidyverse)
library(sf)
library(janitor)
library(stringr)

florida_raw2 <- read_sf("2000s Graph (Figure One)/US_States_and_Counties_WFL1/US_States_and_Counties_WFL1.shp") |>
  clean_names() |>
  mutate(statenam = tolower(statenam)) |>
  filter(statenam == "florida") |>
  rename(counties_flo = icpsrnam) |>
  mutate(
    counties_flo = tolower(counties_flo),
    counties_flo = str_remove(counties_flo, "/.*"),
    counties_flo = str_trim(counties_flo)
  )

results_raw2 <- read_csv("2000s Graph (Figure One)/countypres_2000-2024.csv") |>
  clean_names() |>
  mutate(state = tolower(state))|>
  filter(state == "florida") |>
  filter(year == "2008") |>
  pivot_wider(
    id_cols = c(state, county_name),
    names_from = candidate,
    values_from = candidatevotes
  ) |>
  rename(counties_flo = county_name) |>
  mutate(counties_flo = tolower(counties_flo)) |>
  clean_names()

results_winner2 <- results_raw2 |>
  mutate(
    margin = (barack_obama - john_mccain) / (barack_obama + john_mccain),
    counties_flo = tolower(counties_flo),
    counties_flo = case_when(
      counties_flo == "st. johns" ~ "st johns",
      counties_flo == "st. lucie" ~ "st lucie",
      counties_flo == "desoto" ~ "de soto",
      TRUE ~ counties_flo
    )
  ) |>
  rename(statenam = state)

florida_raw2 <- florida_raw2 |>
  mutate(
    county = str_trim(counties_flo),
    state = str_trim(statenam)
  )

results_winner2 <- results_winner2 |>
  mutate(
    county = str_trim(counties_flo),
    state = str_trim(statenam)
  )

combined_data2 <- florida_raw2 |>
  left_join(
    results_winner2,
    by = c("counties_flo" = "counties_flo",
           "statenam" = "statenam")
  )

ggplot(combined_data2) +
  geom_sf(aes(fill = margin), color = "white") +
  scale_fill_gradient2(
    low = "#8B0000",
    mid = "white",
    high = "#00008B",
    midpoint = 0
  ) +
  theme_void() +
  labs(
    title = "2008 Election Voter Margins",
    fill = "Obama vs. McCain Margin",
    subtitle = "Margin: (Obama votes - McCain votes)/(Obama votes + McCain votes)"
  )

ggsave("2008 Election Voter Margins.png")
