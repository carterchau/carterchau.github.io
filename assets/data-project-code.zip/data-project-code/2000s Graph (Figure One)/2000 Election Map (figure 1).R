library(tidyverse)
library(sf)
library(janitor)
library(stringr)

florida_raw <- read_sf("2000s Graph (Figure One)/US_States_and_Counties_WFL1/US_States_and_Counties_WFL1.shp") |>
  clean_names() |>
  mutate(statenam = tolower(statenam)) |>
  filter(statenam == "florida") |>
  rename(counties_flo = icpsrnam) |>
  mutate(
    counties_flo = tolower(counties_flo),
    counties_flo = str_remove(counties_flo, "/.*"),
    counties_flo = str_trim(counties_flo)
  )

results_raw <- read_csv( "2000s Graph (Figure One)/COUNTY.csv",locale = locale(encoding = "UTF-8")) |>
  clean_names() |>
  mutate(
    state = tolower(iconv(state, to = "UTF-8")),
    county = tolower(iconv(county, to = "UTF-8"))
  ) |>
  filter(state == "florida") |>
  rename(counties_flo = county) |>
  select(state, counties_flo, gore, bush)

results_winner <- results_raw |>
  mutate(
    margin = (gore - bush) / (gore + bush),
    counties_flo = tolower(counties_flo),
    counties_flo = case_when(
      counties_flo == "dade" ~ "miami-dade",
      counties_flo == "st. johns" ~ "st johns",
      counties_flo == "st. lucie" ~ "st lucie",
      counties_flo == "desoto" ~ "de soto",
      TRUE ~ counties_flo
    )
  ) |>
  rename(statenam = state)

florida_raw <- florida_raw |>
  mutate(
    county = str_trim(counties_flo),
    state = str_trim(statenam)
  )

results_winner <- results_winner |>
  mutate(
    county = str_trim(counties_flo),
    state = str_trim(statenam)
  )

combined_data <- florida_raw |>
  left_join(
    results_winner,
    by = c("counties_flo" = "counties_flo",
           "statenam" = "statenam")
  )

ggplot(combined_data) +
  geom_sf(aes(fill = margin), color = "white") +
  scale_fill_gradient2(
    low = "#8B0000",
    mid = "white",
    high = "#00008B",
    midpoint = 0,limits = c(-0.6, 0.2),
    oob = scales::squish,
    breaks = c(-0.6, -0.4, -0.2, 0, 0.2)
  ) +
  theme_void() +
  labs(
    title = "2000 Election By Counties in Florida",
    fill = "Gore vs Bush Margin",
    subtitle = "Margin: (Gore votes - Bush votes)/(Gore votes + Bush votes)"
  )

ggsave("2000s Florida Election Map.png")
