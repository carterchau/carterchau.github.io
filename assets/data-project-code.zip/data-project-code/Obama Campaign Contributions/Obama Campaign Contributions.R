library(tidyverse)
library(waffle)

bo <- data.frame(
  category = c("Small Individual Contributions (< $200)", "Large Contributions", "Other"),
  percent = c(45,43,12)
)

bo_waffle <- bo[rep(1:nrow(bo), bo$percent), ]

bo_waffle$x <- rep(1:10, length.out = nrow(bo_waffle))
bo_waffle$y <- ceiling(seq_along(bo_waffle$x) / 10)

bo_waffle$category <- factor(
  bo_waffle$category,
  levels = c(
    "Small Individual Contributions (< $200)",
    "Large Contributions",
    "Other"
  )
)


ggplot(bo_waffle, aes(x, y, fill = category)) +
  geom_tile(color = "white") +
  coord_equal() +
  scale_y_reverse() +
  labs(
    title = "2008 Obama Campaign Contributions",
    fill = "Contribution Type",
    subtitle = "Each square represents approximately 1% of total contributions (~$7.45 million)",
    caption = "via OpenSecrets"
  ) +
  theme_void() +
  scale_fill_manual(values = c(
    "#022b3a",
    "#1f7a8c",
    "#3a6ea5"
  ))

ggsave("Obama Campaign Contributions.png")
