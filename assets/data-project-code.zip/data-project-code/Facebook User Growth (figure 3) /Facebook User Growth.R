library(tidyverse)
library(janitor)

facebook_data <- read_csv("Facebook User Growth (figure 3) /Facebook User Growth  - Sheet1.csv") |>
  clean_names() |>
  mutate(month_num = match(month, month.name))

cleaner_fb <- facebook_data |>
  mutate(date = as.Date(paste(year, month_num, "01", sep = "-")))

ggplot(cleaner_fb, aes(x = date, y = user_count)) + 
  geom_line(linewidth = 2, color = "#0077b6") + 
  geom_point(size = 3, color = "#03045e") + 
  theme_minimal(base_size = 13)+
  geom_text(aes(label = paste0(user_count,"M")), vjust = -1.5, size = 2.8) +
  labs(
    title = "Facebook User Growth by the Millions",
    x = NULL,
    y = "Number of Facebook Users",
    caption = "via The Associated Press "
  ) +
  scale_y_continuous(labels = function(x) paste0(x, "M"))

ggsave("Facebook User Growth.png")
