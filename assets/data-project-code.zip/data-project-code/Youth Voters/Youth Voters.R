library(tidyverse)
library(janitor)
library(ggimage)

data <- read_csv("Youth Voters/Youth (18-29) Voter Percentage  - Sheet1.csv") |>
  clean_names()

data$image <- c(
  "Youth Voters/Al_Gore,_Vice_President_of_the_United_States,_official_portrait_1994.jpg",
  "Youth Voters/George-W-Bush jp.jpeg",
  "Youth Voters/kerry john.jpeg",
  "Youth Voters/George-W-Bush jp.jpeg",
  "Youth Voters/President_Barack_Obama_(cropped).jpg",
  "Youth Voters/jmac.jpg"
)

data$party <- c("D","R","D","R","D","R")

ggplot(data, aes(x = candidate, y = percentage)) +
  geom_segment(aes(x = candidate, xend = candidate, y = 0, yend = percentage, color = party),
               linewidth = 0.8) +
  scale_color_manual(values = c(
    D = "#0000BB",
    R = "#BB0000"
  ))+
  geom_image(aes(image = image), size = 0.1) +
  facet_wrap(~year, scales = "free_x") +
  geom_text(aes(label = paste0(percentage, "%")),
            vjust = -2.9,
            position = position_dodge(width = 0.5))+
  scale_y_continuous(expand = expansion(mult = c(0, 0.12))) +
  labs(title = "Vote Share Among ages 18-29 by Candidate",
       x = NULL,
       y = NULL,
       caption = "via RoperCenterForPublicResearch",
       fill = NULL) +
  theme_minimal() +
  theme(
    strip.text = element_text(size = 12, face = "bold")
  )+
  theme(legend.position = "none")

ggsave("Youth Voter Share (18-29).png")
